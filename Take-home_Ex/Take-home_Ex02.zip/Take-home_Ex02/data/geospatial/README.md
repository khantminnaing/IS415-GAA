# TAIWAN_2020

SOURCE:
內政部國土測繪中心 版權所有

https://whgis.nlsc.gov.tw/English/5-1Files.aspx

鄉鎮市區界線(TWD97經緯度)1090324	2020/03/27 10:44:13
![](https://github.com/justinelliotmeyers/TAIWAN_2020/blob/master/T_TOWN_2020.jpg)

村(里)界(TWD97經緯度)1090324	2020/03/27 10:41:47
![](https://github.com/justinelliotmeyers/TAIWAN_2020/blob/master/T_VILLAGE_2020.jpg)
